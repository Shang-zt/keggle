from mahjong.env.const import ActionType, ActionLabelRange


class MahjongAction:
    def __init__(self):
        self.action_type = ActionType.ActionTypeNull
        self.player_id = -1
        self.from_player_id = -1
        self.assist_card = []
        self.target_card = None
        self.action_str = None

    def get_action_label(self):
        if self.action_type == ActionType.ActionTypePong:
            action_label = ActionLabelRange.ACTION_PONG_BEG + self.target_card.get_card_id()
        elif self.action_type == ActionType.ActionTypeGong:
            action_label = ActionLabelRange.ACTION_GONG_BEG + self.target_card.get_card_id()
        elif self.action_type == ActionType.ActionTypeDiscard:
            action_label = ActionLabelRange.ACTION_DISCARD_BEG + self.target_card.get_card_id()
        elif self.action_type == ActionType.ActionTypeConcealedGong:
            action_label = ActionLabelRange.ACTION_CONCEALED_GONG_BEG + self.target_card.get_card_id()
        elif self.action_type == ActionType.ActionTypeWait:
            action_label = ActionLabelRange.ACTION_WAIT
        elif self.action_type == ActionType.ActionTypeAddGong:
            action_label = ActionLabelRange.ACTION_ADD_GONG_BEG + self.target_card.get_card_id()
        elif self.action_type == ActionType.ActionTypeDingQue:
            action_label = ActionLabelRange.ACTION_DISCARD_BEG + self.target_card.get_card_type_id()
        else:
            print("unknown_action=", self.action_type)
            assert False
        return action_label
