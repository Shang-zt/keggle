import copy
import random
import numpy as np

from mahjong.env.const import ActionLabelRange, ActionType, WinType


class CommonUtil:
    @staticmethod
    def get_next_player(player_id):
        return (player_id + 1) % 4

    @staticmethod
    def get_cross_player(player_id):
        return (player_id + 2) % 4

    @staticmethod
    def get_last_player(player_id):
        return (player_id + 3) % 4

    @staticmethod
    def get_valid_next_player(player_id, players):
        next_id = -1
        # print('before i want to check ',player_id,[(i,players[i].has_win) for i in range(4)])
        nn_id = player_id
        while next_id != player_id:
            next_id = CommonUtil.get_next_player(nn_id)
            # print('next id',next_id)
            if players[next_id].has_win == WinType.NOT_WIN:
                return next_id
            nn_id = next_id
        assert 0

    @staticmethod
    def get_valid_players(players):
        p = []
        for i in range(4):
            if players[i].has_win == WinType.NOT_WIN:
                p.append(i)
        return p

    @staticmethod
    def get_all_pile_id2cnt(players):
        dic_pile_cid2cnt = dict()
        for i in range(len(players)):
            for sub_pile in players[i].pile:
                for c in sub_pile:
                    cid = c.get_card_id()
                    dic_pile_cid2cnt[cid] = dic_pile_cid2cnt.get(cid, 0) + 1
        return dic_pile_cid2cnt

    @staticmethod
    def trans_actions_from_label2keyval(action: int):
        """
        把0～167的action_label转换为game_core可执行的命令 action_key + action_val
        """
        action_val = None

        if ActionLabelRange.ACTION_PONG_BEG <= action <= ActionLabelRange.ACTION_PONG_END:
            action_key = ActionType.ActionTypePong
            action_val = action - ActionLabelRange.ACTION_PONG_BEG
        elif ActionLabelRange.ACTION_GONG_BEG <= action <= ActionLabelRange.ACTION_GONG_END:
            action_key = ActionType.ActionTypeGong
            action_val = action - ActionLabelRange.ACTION_GONG_BEG
        elif ActionLabelRange.ACTION_CONCEALED_GONG_BEG <= action <= ActionLabelRange.ACTION_CONCEALED_GONG_END:
            action_key = ActionType.ActionTypeConcealedGong
            action_val = action - ActionLabelRange.ACTION_CONCEALED_GONG_BEG
        elif ActionLabelRange.ACTION_ADD_GONG_BEG <= action <= ActionLabelRange.ACTION_ADD_GONG_END:
            action_key = ActionType.ActionTypeAddGong
            action_val = action - ActionLabelRange.ACTION_ADD_GONG_BEG
        elif ActionLabelRange.ACTION_CHOW_BEG + 1 <= action <= ActionLabelRange.ACTION_CHOW_END:
            assert False, "chow is invalid"
        elif action == 105:
            action_key = ActionType.ActionTypeDrawGuaFeng
        elif ActionLabelRange.ACTION_DISCARD_BEG <= action <= ActionLabelRange.ACTION_DISCARD_END:
            action_key = ActionType.ActionTypeDiscard
            action_val = action - ActionLabelRange.ACTION_DISCARD_BEG
        elif action == ActionLabelRange.ACTION_PASS:
            action_key = ActionType.ActionTypePass
        elif action == ActionLabelRange.ACTION_GET_CARD:
            action_key = ActionType.ActionTypeDraw
        elif action == ActionLabelRange.ACTION_HU:
            action_key = ActionType.ActionTypeHu
        elif action == ActionLabelRange.ACTION_PASS_HU:
            action_key = ActionType.ActionTypePassHu
        elif action == ActionLabelRange.ACTION_WAIT:
            action_key = ActionType.ActionTypeWait
        elif ActionLabelRange.ACTION_QUE_BEG <= action <= ActionLabelRange.ACTION_QUE_END:
            action_key = ActionType.ActionTypeDingQue
            action_val = action - ActionLabelRange.ACTION_QUE_BEG
        else:
            assert False, f"unknown action label: {action}"
        return action_key, action_val

    @staticmethod
    def trans_cards_from_obj2label(mahjong_cards, num_ele=34):
        lis_card_id = [-1] * num_ele
        idx = 0
        for card in mahjong_cards[::-1]:
            lis_card_id[idx] = card.get_card_id()
            idx += 1
            if idx >= num_ele:
                break
        return lis_card_id

    @staticmethod
    def trans_actions_from_obj2label(mahjong_actions, num_ele=50):
        lis_action_id = [-1] * num_ele
        idx = 0
        for action in mahjong_actions:
            lis_action_id[idx] = action.get_action_label()
            idx += 1
            if idx >= num_ele:
                break
        return lis_action_id


class ShantenUtil(object):
    Shanten_Limit_Num = 4
    DIC_DEFCardId2BotCardId = {
        0: 19,
        1: 20,
        2: 21,
        3: 22,
        4: 23,
        5: 24,
        6: 25,
        7: 26,
        8: 27,
        9: 1,
        10: 2,
        11: 3,
        12: 4,
        13: 5,
        14: 6,
        15: 7,
        16: 8,
        17: 9,
        18: 10,
        19: 11,
        20: 12,
        21: 13,
        22: 14,
        23: 15,
        24: 16,
        25: 17,
        26: 18,
        27: 33,
        28: 32,
        29: 34,
        30: 28,
        31: 30,
        32: 31,
        33: 29,
    }

    DIC_BotCardId2DEFCardId = {}
    for card_id in DIC_DEFCardId2BotCardId:
        DIC_BotCardId2DEFCardId[DIC_DEFCardId2BotCardId[card_id]] = card_id

    DIC_DEFActType2BotActId = {
        None: 1,
        ActionType.ActionTypeDraw: 2,
        ActionType.ActionTypeDiscard: 5,
        ActionType.ActionTypePong: 6,
        ActionType.ActionTypeChow: 7,
        ActionType.ActionTypeGong: 8,
        ActionType.ActionTypeConcealedGong: 8,
        ActionType.ActionTypeAddGong: 9,
    }

    Gong_Act_List = [i for i in range(ActionLabelRange.ACTION_GONG_BEG, ActionLabelRange.ACTION_GONG_END + 1)]
    Concealed_Gong_Act_List = [
        i for i in range(ActionLabelRange.ACTION_CONCEALED_GONG_BEG, ActionLabelRange.ACTION_CONCEALED_GONG_END + 1)
    ]
    Add_Gong_Act_List = [
        i for i in range(ActionLabelRange.ACTION_ADD_GONG_BEG, ActionLabelRange.ACTION_ADD_GONG_END + 1)
    ]
    Pong_Act_List = [i for i in range(ActionLabelRange.ACTION_PONG_BEG, ActionLabelRange.ACTION_PONG_END + 1)]
    Chow_Act_List = [i for i in range(ActionLabelRange.ACTION_CHOW_BEG, ActionLabelRange.ACTION_CHOW_END + 1)]
    Discard_Act_List = [i for i in range(ActionLabelRange.ACTION_DISCARD_BEG, ActionLabelRange.ACTION_DISCARD_END + 1)]
    Draw_Act_List = ActionLabelRange.ACTION_GET_CARD
    Pass_Act_List = ActionLabelRange.ACTION_PASS

    def __init__(self, player_id):
        self.last_card = None
        self.player_id = player_id

    def _get_card_from(self, player_id):
        if self.player_id == player_id:
            return 0
        elif player_id == CommonUtil.get_last_player(self.player_id):
            return 1
        elif player_id == CommonUtil.get_cross_player(self.player_id):
            return 2
        elif player_id == CommonUtil.get_next_player(self.player_id):
            return 3
        else:
            assert False

    def _get_hand_list_and_num(self, bot_state):
        hand = [i for i in bot_state["hand"] if i >= 0]
        hand_list = []
        for h in hand:
            hand_list.append(ShantenUtil.DIC_DEFCardId2BotCardId[h])

        hand_num = []
        for p in bot_state["chow_pong_gong"]:
            hand_num.append(13 - len(p) * 3)

        concealed_gong = []
        for cg in bot_state["concealed_gong"]:
            concealed_gong.append([i for i in cg if i >= 0])
        player = self.player_id
        pos = -1
        for p in range(player, player + 4):
            pos += 1
            for idx in range(0, len(concealed_gong[pos]), 4):
                hand_num[p % 4] -= 3
        hand_num[self.player_id] = len(hand)
        return hand_list, hand_num

    def _get_fulu_list(self, bot_state):
        concealed_gong = []
        for cg in bot_state["concealed_gong"]:
            concealed_gong.append([i for i in cg if i >= 0])

        fulu = []
        for p in range(4):
            player_fulu = []
            for pile in bot_state["chow_pong_gong"][p]:
                pile_cards = copy.deepcopy(pile)
                target_user = pile_cards.pop(0)
                if pile_cards[0] != pile_cards[1]:
                    # 吃
                    target_card = pile_cards[0]
                    pile_cards.sort()
                    tmp_pile_cards_id = [
                        ShantenUtil.DIC_DEFCardId2BotCardId[pile_cards[1]],
                        ShantenUtil.DIC_DEFCardId2BotCardId[pile_cards[2]],
                    ]
                    if target_card == pile_cards[0]:
                        tmp_pile_cards_id.append(1)
                    elif target_card == pile_cards[1]:
                        tmp_pile_cards_id.append(2)
                    else:
                        tmp_pile_cards_id.append(3)
                    player_fulu.append(tmp_pile_cards_id)
                else:
                    if len(pile_cards) == 3:
                        player_fulu.append(
                            [
                                ShantenUtil.DIC_DEFCardId2BotCardId[pile_cards[1]],
                                ShantenUtil.DIC_DEFCardId2BotCardId[pile_cards[2]],
                                self._get_card_from(target_user),
                            ]
                        )
                    else:
                        player_fulu.append(
                            [ShantenUtil.DIC_DEFCardId2BotCardId[pile_cards[1]], 0, self._get_card_from(target_user)]
                        )
            fulu.append(player_fulu)
        player = self.player_id
        pos = -1
        for p in range(player, player + 4):
            pos += 1
            for idx in range(0, len(concealed_gong[pos]), 4):
                if p % 4 == self.player_id:
                    fulu[p % 4].append([ShantenUtil.DIC_DEFCardId2BotCardId[concealed_gong[pos][idx]], 0, 0])
                else:
                    fulu[p % 4].append([0, 0, 0])
        return fulu

    @staticmethod
    def _get_discard_num(bot_state):
        discard_num = 0
        for hc in bot_state["history_cards"]:
            for card in hc:
                if 0 <= card <= 33:
                    discard_num += 1
        return discard_num

    @staticmethod
    def _get_remain_and_deck_num(bot_state):
        remain = [4] * 35
        remain[0] = 0  # 未使用的id
        visible_card_list = [
            bot_state["hand"],
            bot_state["concealed_gong"][0],
            bot_state["history_cards"][0],
            bot_state["history_cards"][1],
            bot_state["history_cards"][2],
            bot_state["history_cards"][3],
        ]
        for vcl in visible_card_list:
            for card in vcl:
                if 0 <= card <= 33:
                    remain[ShantenUtil.DIC_DEFCardId2BotCardId[card]] -= 1
        for p in range(4):
            for pile in bot_state["chow_pong_gong"][p]:
                for k in pile[2:]:
                    remain[ShantenUtil.DIC_DEFCardId2BotCardId[k]] -= 1
        deck_sum_cnt = 0
        for i in range(len(remain)):
            if remain[i] < 0:
                remain[i] = 0
            deck_sum_cnt += remain[i]
        deck_player_cnt = [len(bot_state["lis_deck"][k]) for k in range(4)]
        return remain, deck_sum_cnt, deck_player_cnt

    def _get_last_info(self, bot_state):
        hand = [i for i in bot_state["hand"] if i >= 0]
        if bot_state["last_action"] in [None, ActionType.ActionTypeDraw]:
            last_card = hand.pop(0)
        else:
            last_card = bot_state["last_card"]
            if last_card == -1:
                last_card = self.last_card
        last_card_new = ShantenUtil.DIC_DEFCardId2BotCardId[last_card]
        self.last_card = ShantenUtil.DIC_BotCardId2DEFCardId[last_card_new]
        last_player = bot_state["last_player"]
        last_action = bot_state["last_action"]
        last_action_idx = ShantenUtil.DIC_DEFActType2BotActId[last_action]
        return last_card_new, last_player, last_action_idx

    def _extract_bot_obs(self, bot_state):
        hand_list, hand_num = self._get_hand_list_and_num(bot_state)
        fulu = self._get_fulu_list(bot_state)
        discard_num = self._get_discard_num(bot_state)
        remain, deck_sum_cnt, deck_player_cnt = self._get_remain_and_deck_num(bot_state)
        last_card, last_player, last_action = self._get_last_info(bot_state)

        quan_id = bot_state["quan_id"]

        bot_obs = [
            hand_list,
            hand_num,
            fulu,
            remain,
            deck_player_cnt,
            self.player_id,
            quan_id,
            last_player,
            deck_sum_cnt,
            discard_num,
            last_action,
            last_card,
            ShantenUtil.Shanten_Limit_Num,
        ]
        return bot_obs

    def select_action(self, legal_actions_list, shanten_prob):
        if ActionLabelRange.ACTION_HU in legal_actions_list:
            return ActionLabelRange.ACTION_HU
        legal_action_chow = list(set(legal_actions_list).intersection(set(ShantenUtil.Chow_Act_List)))
        legal_action_pong = list(set(legal_actions_list).intersection(set(ShantenUtil.Pong_Act_List)))

        legal_action_gong = list(set(legal_actions_list).intersection(set(ShantenUtil.Gong_Act_List)))
        legal_action_concealed_gong = list(
            set(legal_actions_list).intersection(set(ShantenUtil.Concealed_Gong_Act_List))
        )
        legal_action_add_gong = list(set(legal_actions_list).intersection(set(ShantenUtil.Add_Gong_Act_List)))
        legal_action_gong_all = legal_action_gong + legal_action_concealed_gong + legal_action_add_gong

        legal_action_discard = list(set(legal_actions_list).intersection(set(ShantenUtil.Discard_Act_List)))

        if shanten_prob[-1] == 1:
            if len(legal_action_chow) > 0:
                action_label = random.choice(legal_action_chow)
            elif len(legal_action_pong) > 0:
                action_label = random.choice(legal_action_pong)
            elif len(legal_action_gong_all) > 0:
                action_label = random.choice(legal_action_gong_all)
            elif len(legal_action_discard) > 0:
                act = np.argmax(
                    shanten_prob[ActionLabelRange.ACTION_DISCARD_BEG : ActionLabelRange.ACTION_DISCARD_END + 1]
                )
                action_label = act + ActionLabelRange.ACTION_DISCARD_BEG
            elif ActionLabelRange.ACTION_GET_CARD in legal_actions_list:
                action_label = ActionLabelRange.ACTION_GET_CARD
            elif ActionLabelRange.ACTION_PASS in legal_actions_list:
                action_label = ActionLabelRange.ACTION_PASS
            else:
                action_label = None
        else:
            action_label = np.argmax(shanten_prob[:-1])
        return action_label


def find_fan(player, fan_type):
    for l in player.score_types_record:
        for score in l:
            if score.is_pos:
                for fan in score.fan_type:
                    if fan == fan_type:
                        return 1
    return 0
