from collections import defaultdict

from mahjong.env.const import CardId, ActionType, CARD3_SET_NUM, WinType, WinType2StrDict, CardId2StrDict, FanType
from mahjong.env.env_utils import CommonUtil
from mahjong.env.score import MahjongScore
from mahjong.env.card import MahjongCard
import copy


class FakeDealer:
    def is_empty(self):
        return False


def check_daduizi(cnt_cards):
    daduizi_cnt = 0
    for i in range(27):
        if cnt_cards[i] == 1:
            return False
        if cnt_cards[i] == 2:
            daduizi_cnt += 1
    if daduizi_cnt == 1:
        return True
    return False


class MahjongJudger(object):
    min_fan_score = 8

    def __init__(self):
        pass

    @staticmethod
    def judge_add_gong(player):
        """
        判断玩家能否加杠操作
        """
        lis_add_gong = []
        for cid in player.dic_hand_id2cnt:
            if player.dic_hand_id2cnt[cid] > 1:
                continue
            # 新摸到的牌已碰过
            for cur_pile in player.pile:
                cnt = 0
                for card in cur_pile:
                    if card.card_id == cid:
                        cnt += 1
                    else:
                        break
                if cnt == 3:
                    lis_add_gong.append(cid)
                elif cnt > 0:
                    break
        if len(lis_add_gong) > 0:
            return True, lis_add_gong
        return False, None

    @staticmethod
    def judge_concealed_gong(player):
        """
        判断玩家手牌能否暗杠操作
        """
        lis_gong = []
        for card_id in player.dic_hand_id2cnt:
            if player.dic_hand_id2cnt[card_id] == 4:
                lis_gong.append(card_id)
        if len(lis_gong) > 0:
            return True, lis_gong
        return False, None

    @staticmethod
    def cal_set(cards):
        """Calculate the set for given cards
        Args:
            cards (list): List of cards.

        Return:
            is_set3 (bool):
            set_count (int): num of 3-element set, valid only if is_set3 == true
        """
        # get all of the traits of each type in hand (except dragons and winds)
        _dict_by_type = defaultdict(list)
        set_count = 0

        # 计算只能构成[A,A,A]这样三元组的组合数
        t_dic_no_chow = {}
        for card_id in cards:
            if card_id not in CardId2StrDict:
                if card_id not in t_dic_no_chow:
                    t_dic_no_chow[card_id] = 0
                t_dic_no_chow[card_id] += 1
        for card_id in t_dic_no_chow:
            if t_dic_no_chow[card_id] == 3:
                set_count += 1
            else:
                return False, set_count

        # 计算剩余的三元组
        for card_id in cards:
            if card_id not in CardId2StrDict:
                continue
            else:
                _type = int(card_id / 9)
                _trait = int(card_id % 9)
                _dict_by_type[_type].append(_trait)
        for _type in _dict_by_type.keys():
            values = sorted(_dict_by_type[_type])
            is_3_set, set_num = MahjongJudger.sort_by_3_elements(values)
            if is_3_set:
                set_count += set_num
            else:
                return False, set_count
        return True, set_count

    @staticmethod
    def sort_by_3_elements(lis):
        next_ = -1
        if len(lis) % 3 != 0:
            return False, 0
        assert len(lis) % 3 == 0
        for idx_i in range(len(lis)):
            if idx_i <= next_:
                continue
            k = idx_i % 3
            if k == 0:
                # 3元组的首位
                if lis[idx_i] == lis[idx_i + 1] and lis[idx_i] == lis[idx_i + 2]:
                    next_ = idx_i + 2
                    continue
                min_value = min(lis[idx_i:])  # 寻找最小值
                if lis[idx_i] != min_value:
                    min_idx = lis[idx_i:].index(min_value)
                    lis[idx_i], lis[idx_i + min_idx] = lis[idx_i + min_idx], lis[idx_i]
            elif k != 0:
                #
                last_value = lis[idx_i - 1]
                exp_value = last_value + 1
                if exp_value in lis[idx_i:]:
                    exp_idx = lis[idx_i:].index(exp_value) + idx_i
                    lis[idx_i], lis[exp_idx] = lis[exp_idx], lis[idx_i]
                else:
                    return False, len(lis) / 3
        return True, len(lis) / 3

    @staticmethod
    def is_rob_gong_card(players, dealer, current_player):
        total_fan = None
        next_player = CommonUtil.get_next_player(current_player)
        cross_player = CommonUtil.get_cross_player(current_player)
        last_player = CommonUtil.get_last_player(current_player)
        lis_pid = list()
        play_order = list([next_player, cross_player, last_player])
        play_order = [player_id for player_id in play_order if players[player_id].has_win == WinType.NOT_WIN]

        for pid in play_order:
            players[pid].valid_act = dict()
        # check who wins
        for pid in play_order:
            win_type = MahjongJudger.judge_hu(
                lis_hand=[c.card_id for c in players[pid].hand],
                dic_hand_id2cnt=players[pid].dic_hand_id2cnt,
                set_count=(len(players[pid].pile) + len(players[pid].hidden_pile)),
                win_tile_id=players[current_player].add_gong_card.card_id,
                que_men=players[pid].que_men,
            )
            if win_type is not None:
                total_fan = MahjongJudger.calculate_fan_all_simple(
                    players[pid],
                    dealer,
                    win_card=players[current_player].add_gong_card,
                    is_rob_the_gong=True,
                    win_type=win_type,
                )
                assert total_fan is not None
                if total_fan is not None:
                    lis_pid.append(
                        (
                            pid,
                            {
                                "set_hu": {
                                    "card_id": players[current_player].add_gong_card.card_id,
                                    "win_type": win_type,
                                    "add_gong_card": players[current_player].add_gong_card,
                                }
                            },
                        )
                    )
                    # players[pid].valid_act[ActionType.ActionTypeHu] = players[current_player].add_gong_card.card_id
                    # players[pid].valid_act[ActionType.ActionTypePassHu] = 1
                    # players[pid].rob_gong_card = players[current_player].add_gong_card
                    # players[pid].set_win_type(win_type=win_type)
            else:
                players[pid].rob_gong_card = None
        if len(lis_pid) > 0:
            lis_pid.append((current_player, {"set_drawGuaFeng": True}))
            # players[current_player].valid_act[ActionType.ActionTypeDrawGuaFeng] = 1
        return lis_pid, total_fan

    @staticmethod
    def is_target_card(players, current_player, dealer, card_to_use):
        """
        判断当前玩家刚打出来的牌能否被其他玩家胡/杠(碰)/吃
        """
        total_fan = None
        next_player = CommonUtil.get_next_player(current_player)
        cross_player = CommonUtil.get_cross_player(current_player)
        last_player = CommonUtil.get_last_player(current_player)
        lis_pid = list()
        play_order = list([next_player, cross_player, last_player])
        play_order = [player_id for player_id in play_order if players[player_id].has_win == WinType.NOT_WIN]
        next_player = play_order[0]
        for pid in play_order:
            players[pid].valid_act = dict()
        # check who wins
        for pid in play_order:
            win_type = MahjongJudger.judge_hu(
                lis_hand=[c.card_id for c in players[pid].hand],
                dic_hand_id2cnt=players[pid].dic_hand_id2cnt,
                set_count=(len(players[pid].pile) + len(players[pid].hidden_pile)),
                win_tile_id=card_to_use.get_card_id(),
                que_men=players[pid].que_men,
            )
            if win_type is not None:
                total_fan = MahjongJudger.calculate_fan_all_simple(
                    players[pid], dealer, win_card=card_to_use, is_rob_the_gong=False, win_type=win_type
                )
                assert total_fan is not None
                if total_fan is not None:
                    lis_pid.append((pid, {"set_hu": {"card_id": card_to_use.get_card_id(), "win_type": win_type}}))
                    # players[pid].valid_act[ActionType.ActionTypeHu] = card_to_use.get_card_id()
                    # players[pid].valid_act[ActionType.ActionTypePassHu] = 1
                    # players[pid].set_win_type(win_type=win_type)

        # check who pg
        for pid in play_order:
            pg_type, pg_card_id_list = MahjongJudger.judge_pg_with_extra_card(players[pid], card_to_use)
            if pg_type is not None:
                # if pid in lis_pid:
                #     lis_pid.append((pid,{'set_hu':None,'set_'}))
                if pg_type == ActionType.ActionTypePong:
                    if len(dealer.lis_deck[pid]) > 0 and len(dealer.lis_deck[next_player]) > 0:
                        # players[pid].valid_act[ActionType.ActionTypePong] = pg_card_id_list
                        lis_pid.append((pid, {"set_pong": pg_card_id_list}))
                elif pg_type == ActionType.ActionTypeGong:
                    # if len(dealer.lis_deck[pid]) > 0 and len(dealer.lis_deck[next_player]) > 0:
                    # players[pid].valid_act[ActionType.ActionTypePong] = pg_card_id_list
                    # lis_pid.append((pid, {'set_pong': pg_card_id_list}))
                    if len(dealer.lis_deck[pid]) > 0 and len(dealer.lis_deck[next_player]) > 0:
                        # 自身牌墙非空时可杠别人的牌
                        # next_player的牌墙非空才可杠
                        # players[pid].valid_act[ActionType.ActionTypeGong] = pg_card_id_list
                        lis_pid.append((pid, {"set_gong": pg_card_id_list}))
                else:
                    assert False
                break

        # if len(lis_pid) > 0:
        #     lis_new_pid = list()
        #     for pid in lis_pid:
        #         if len(players[pid].valid_act) > 0:
        #             lis_new_pid.append(pid)
        #     lis_pid = lis_new_pid
        # 若存在某个玩家可以胡/杠(碰)/吃刚打出来的牌, 则把下家也加进队列
        # if len(lis_pid) > 0:
        #     if next_player not in lis_pid:
        #         lis_pid.append(next_player)

        # for pid in lis_pid:
        #     if pid != next_player:
        #         非下家,补充默认选项——pass
        # action_lis = list(players[pid].valid_act.keys())
        # if ActionType.ActionTypePong in action_lis \
        #         or ActionType.ActionTypeGong in action_lis:
        # 不碰/不吃/不杠
        # players[pid].valid_act[ActionType.ActionTypePass] = 1
        # else:
        # 下家,补充默认选项——摸牌
        # players[pid].valid_act[ActionType.ActionTypeDraw] = 1
        if len(lis_pid) > 0:
            for pid in play_order:
                lis_pid.append((pid, {"set_draw": True}))
        return lis_pid, total_fan

    @staticmethod
    def judge_pg_with_extra_card(player, dealer_top_card):
        """
        碰或杠别人刚打出来的牌
        """
        pg_type = None
        pg_card_ids = []
        card_id = dealer_top_card.get_card_id()
        if card_id // 9 == player.que_men:
            return None, pg_card_ids
        cnt = player.dic_hand_id2cnt.get(card_id, 0)
        if cnt == 3:
            pg_type = ActionType.ActionTypeGong
            pg_card_ids = [card_id]
        elif cnt == 2:
            pg_type = ActionType.ActionTypePong
            pg_card_ids = [card_id]
        return pg_type, pg_card_ids

    @staticmethod
    def judge_common_pattern_win(lis_hand, dic_hand_id2cnt, set_count, win_tile_id=None):
        bak_lis_hand = lis_hand.copy()
        if win_tile_id is not None:
            bak_lis_hand.append(win_tile_id)
        else:
            # 最近摸进的牌
            win_tile_id = bak_lis_hand[-1]
        left_id = win_tile_id - 1
        right_id = win_tile_id + 1
        if win_tile_id not in dic_hand_id2cnt and left_id not in dic_hand_id2cnt and right_id not in dic_hand_id2cnt:
            return False
        count_dict = {}
        for card in bak_lis_hand:
            if card in count_dict:
                count_dict[card] += 1
            else:
                count_dict[card] = 1

        if set_count >= CARD3_SET_NUM and len(set(bak_lis_hand)) == 1 and len(bak_lis_hand) == 2:
            return True
        for each in count_dict:
            tmp_hand = bak_lis_hand.copy()
            if count_dict[each] >= 2:
                for _ in range(2):
                    tmp_hand.pop(tmp_hand.index(each))
                is_3_set, tmp_set_count = MahjongJudger.cal_set(tmp_hand)
                if is_3_set:
                    if tmp_set_count + set_count >= CARD3_SET_NUM:
                        return True
        return False

    @staticmethod
    def judge_seven_pairs_win(lis_hand, dic_hand_id2cnt, win_tile_id=None):
        if len(lis_hand) < 13:
            return False
        if len(lis_hand) == 13 and win_tile_id is None:
            return False
        if len(lis_hand) == 14 and win_tile_id is not None:
            return False
        for card_id in dic_hand_id2cnt:
            if card_id == win_tile_id:
                if dic_hand_id2cnt[card_id] % 2 != 1:
                    return False
            else:
                if dic_hand_id2cnt[card_id] % 2 != 0:
                    return False
        return True

    @staticmethod
    def judge_hu(lis_hand, dic_hand_id2cnt, que_men, set_count=0, win_tile_id=None):
        win_type = None
        for card in lis_hand:
            if card // 9 == que_men:
                return None
        # 0. 七对判断
        if win_type is None and MahjongJudger.judge_seven_pairs_win(
            lis_hand=lis_hand, dic_hand_id2cnt=dic_hand_id2cnt, win_tile_id=win_tile_id
        ):
            win_type = WinType.SEVEN_PAIRS
        # 4. 普通胡判断
        if win_type is None and MahjongJudger.judge_common_pattern_win(
            lis_hand=lis_hand, dic_hand_id2cnt=dic_hand_id2cnt, set_count=set_count, win_tile_id=win_tile_id
        ):
            win_type = WinType.COMMON_WIN
        return win_type

    @staticmethod
    def judge_hua_zhu(lis_hand, dic_hand_id2cnt, que_men, set_count=0, win_tile_id=None):
        for card in lis_hand:
            if card // 9 == que_men:
                return True
        return False

    @staticmethod
    def judge_ting(lis_hand, dic_hand_id2cnt, set_count, que_men, player):
        # win_type = None
        for card in lis_hand:
            if card // 9 == que_men:
                return None
        # 0. 七对判断
        ting = []
        for win_tile_id in CardId2StrDict.keys():
            win_card = MahjongCard(win_tile_id)
            win_type = MahjongJudger.judge_seven_pairs_win(
                lis_hand=lis_hand, dic_hand_id2cnt=dic_hand_id2cnt, win_tile_id=win_tile_id
            )
            if win_type:
                fake_dealer = FakeDealer()
                ting.append(
                    [
                        WinType.SEVEN_PAIRS,
                        win_tile_id,
                        MahjongJudger.calculate_fan_all_simple(
                            player, win_card=win_card, is_rob_the_gong=False, dealer=fake_dealer, win_type=win_type
                        ),
                    ]
                )

            # 4. 普通胡判断
            win_type = MahjongJudger.judge_common_pattern_win(
                lis_hand=lis_hand, dic_hand_id2cnt=dic_hand_id2cnt, set_count=set_count, win_tile_id=win_tile_id
            )
            if win_type:
                fake_dealer = FakeDealer()
                ting.append(
                    [
                        WinType.COMMON_WIN,
                        win_tile_id,
                        MahjongJudger.calculate_fan_all_simple(
                            player, win_card=win_card, is_rob_the_gong=False, dealer=fake_dealer, win_type=win_type
                        ),
                    ]
                )
        if len(ting) == 0:
            return None
        else:

            sorted(ting, key=lambda x: x[2].get_score(), reverse=True)
            # for i in ting:
            #     print(i.get_score())
            # print(ting[0][2])

            # assert 0
            return ting[0][2]
        # return ting if len(ting) > 0 else None

    @staticmethod
    def is_last_tile(state, win_card):
        table_cards_id = [card.get_card_id() for card in state["table"]]
        pile_cards = []
        for i in range(4):
            pile_cards.extend(state["players_pile"][i])

        pile_cards_id = []
        for cards in pile_cards:
            pile_cards_id.extend([card.get_card_id() for card in cards])

        known_cards_id = pile_cards_id + table_cards_id
        return known_cards_id.count(win_card) == 3

    @staticmethod
    def is_last_tile_simple(dealer, dic_pile_cid2cnt, win_card_id):
        for card in dealer.table:
            cid = card.get_card_id()
            dic_pile_cid2cnt[cid] = dic_pile_cid2cnt.get(cid, 0) + 1
        win_card_cnt = dic_pile_cid2cnt.get(win_card_id, 0)
        return win_card_cnt == 4

    @staticmethod
    def calculate_fan_all_simple(player, dealer, win_card=None, is_rob_the_gong=False, win_type=None):
        reflect = {}
        for i in range(CardId.BAMBOO_1, CardId.BAMBOO_9 + 1):
            reflect[i] = "T{}".format(i + 1)
        for i in range(CardId.DOT_1, CardId.DOT_9 + 1):
            reflect[i] = "B{}".format(i % 9 + 1)
        for i in range(CardId.CHARACTER_1, CardId.CHARACTER_9 + 1):
            reflect[i] = "W{}".format(i % 9 + 1)
        assert win_type == WinType.COMMON_WIN or win_type == WinType.SEVEN_PAIRS, win_type
        # assert win_card is not None
        if win_card is None:
            win_card = copy.deepcopy(player.hand[-1])
            hand = copy.deepcopy(player.hand)
        else:
            hand = copy.deepcopy(player.hand) + [win_card]
        #####################################
        # 判断 清一色 门清 等
        is_gong_kai_or_pao = win_card.gonging
        is_seven = win_type == WinType.SEVEN_PAIRS
        is_self_drawn = win_card.user_id == player.player_id
        is_last_card = dealer.is_empty()
        is_qingyise = False
        is_menqing = False
        is_daduizi = False
        is_d91 = False
        cnt_cards = [0 for _ in range(27)]
        huazhu_types = []
        for c in hand:
            if c.card_id // 9 not in huazhu_types:
                huazhu_types.append(c.card_id // 9)
            cnt_cards[c.card_id] += 1
        is_daduizi = check_daduizi(cnt_cards)

        for cc in player.hidden_pile:
            for c in cc:
                if c.card_id // 9 not in huazhu_types:
                    huazhu_types.append(c.card_id // 9)
                cnt_cards[c.card_id] += 1
        for cc in player.pile:
            for c in cc:
                if c.card_id // 9 not in huazhu_types:
                    huazhu_types.append(c.card_id // 9)
                cnt_cards[c.card_id] += 1

        if len(huazhu_types) == 1:
            is_qingyise = True
        if len(player.pile) == 0 and len(player.hidden_pile) == 0:
            is_menqing = True
        if (
            cnt_cards[0] == 0
            and cnt_cards[8] == 0
            and cnt_cards[9] == 0
            and cnt_cards[17] == 0
            and cnt_cards[18] == 0
            and cnt_cards[26] == 0
        ):
            is_d91 = True
        cnt_gong = sum([1 for i in cnt_cards if i == 4])

        score = MahjongScore()
        tmp1 = [is_daduizi, is_qingyise, is_menqing, is_seven, is_last_card, is_d91, is_self_drawn, is_rob_the_gong]
        tmp2 = [
            FanType.DA_DUI_ZI,
            FanType.QING_YI_SE,
            FanType.MEN_QING,
            FanType.SEVEN_PAIRS,
            FanType.HAI_DI,
            FanType.NO_19,
            FanType.ZI_MO,
            FanType.ROB_GONG,
        ]
        score.fan_type.append(FanType.DEFAULT)
        for k1, k2 in zip(tmp1, tmp2):
            if k1:
                score.fan_type.append(k2)
        if cnt_gong > 0:
            if cnt_gong == 1:
                score.fan_type.append(FanType.SINGLE_GONG)
            elif cnt_gong == 2:
                score.fan_type.append(FanType.DOUBLE_GONG)
            elif cnt_gong == 3:
                score.fan_type.append(FanType.TRIPLE_GONG)
            elif cnt_gong == 4:
                score.fan_type.append(FanType.QUADRUPLE_GONG)
            else:
                assert 0
        if is_gong_kai_or_pao:
            if is_self_drawn:
                score.fan_type.append(FanType.GONG_HUA)
            else:
                score.fan_type.append(FanType.GONG_PAO)
        score.win_id = player.player_id
        score.loss_id = -1 if is_self_drawn else win_card.user_id
        score.cause_card = win_card
        score.is_pos = True

        return score


""" test
"""


def gen_dic(lis):
    dic = dict()
    for e in lis:
        dic[e] = dic.get(e, 0) + 1
    return dic


if __name__ == "__main__":
    x = lambda: None
    setattr(x, "is_empty", lambda: False)
    y = lambda: None
    setattr(y, "hand", [MahjongCard(2), MahjongCard(2), MahjongCard(7), MahjongCard(7)])
    setattr(y, "player_id", 0)
    setattr(y, "hidden_pile", [])
    setattr(y, "pile", [])
    # y.hand=
    a = MahjongJudger.calculate_fan_all_simple(
        y, x, win_card=MahjongCard(2), is_rob_the_gong=False, win_type=WinType.COMMON_WIN
    )
    print(a.fan_type, a.get_score())
