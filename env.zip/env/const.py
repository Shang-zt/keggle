MAX_HAND_CARD_NUM = 14  # 手牌数上限
CARD3_SET_NUM = 4  # 3*N+2中的N


class ActionType:
    ActionTypeNull = 0
    ActionTypeDraw = 1
    ActionTypeDiscard = 2
    ActionTypeChow = 3
    ActionTypePong = 4
    ActionTypeGong = 5  # 明杠
    ActionTypeHu = 6
    ActionTypePass = 7  # 不吃/不碰/不杠
    ActionTypeConcealedGong = 8  # 暗杠
    ActionTypePassHu = 9  # 不胡
    ActionTypeWait = 10  # 听牌
    ActionTypeAddGong = 11  # 加杠
    ActionTypeDingQue = 12
    ActionTypeHasWin = 13
    ActionTypeDrawGuaFeng = 14


# action_label取值范围
class ActionLabelRange:
    ACTION_GET_CARD = 0
    ACTION_HU = 1
    ACTION_PASS = 2  # 不吃/不碰/不杠
    ACTION_DISCARD_BEG = 3
    ACTION_DISCARD_END = 36
    ACTION_PONG_BEG = 37  # [37:70]
    ACTION_PONG_END = 70
    ACTION_GONG_BEG = 71  # [71:104]
    ACTION_GONG_END = 104
    ACTION_CHOW_BEG = 105  # [105:167] # 105 被用来做抽牌加刮风
    ACTION_CHOW_END = 167
    ACTION_CONCEALED_GONG_BEG = 168
    ACTION_CONCEALED_GONG_END = 201
    ACTION_PASS_HU = 202  # 不胡
    ACTION_WAIT = 203  # 听牌
    ACTION_ADD_GONG_BEG = 204  # 加杠[204:237]
    ACTION_ADD_GONG_END = 237
    ACTION_VALID = 238  # 用于对敌方暗杠
    ACTION_QUE_BEG = 239
    ACTION_QUE_END = 242
    ACTION_NULL = 243


class WinType:
    NOT_WIN = 0
    COMMON_WIN = 1  # m * ABC + n * AAA + BB型
    SEVEN_PAIRS = 2  # 七对


WinType2StrDict = {
    WinType.COMMON_WIN: "common_win",
    WinType.SEVEN_PAIRS: "seven_pairs",
}


class CardType:
    BAMBOO = 0
    CHARACTER = 1
    DOT = 2
    NULL = 3


# Make sure CardID // 9 == CardType
class CardId:
    BAMBOO_1 = 0
    BAMBOO_2 = 1
    BAMBOO_3 = 2
    BAMBOO_4 = 3
    BAMBOO_5 = 4
    BAMBOO_6 = 5
    BAMBOO_7 = 6
    BAMBOO_8 = 7
    BAMBOO_9 = 8
    CHARACTER_1 = 9
    CHARACTER_2 = 10
    CHARACTER_3 = 11
    CHARACTER_4 = 12
    CHARACTER_5 = 13
    CHARACTER_6 = 14
    CHARACTER_7 = 15
    CHARACTER_8 = 16
    CHARACTER_9 = 17
    DOT_1 = 18
    DOT_2 = 19
    DOT_3 = 20
    DOT_4 = 21
    DOT_5 = 22
    DOT_6 = 23
    DOT_7 = 24
    DOT_8 = 25
    DOT_9 = 26


CardId2StrDict = {
    0: "bamboo-1",
    1: "bamboo-2",
    2: "bamboo-3",
    3: "bamboo-4",
    4: "bamboo-5",
    5: "bamboo-6",
    6: "bamboo-7",
    7: "bamboo-8",
    8: "bamboo-9",
    9: "characters-1",
    10: "characters-2",
    11: "characters-3",
    12: "characters-4",
    13: "characters-5",
    14: "characters-6",
    15: "characters-7",
    16: "characters-8",
    17: "characters-9",
    18: "dots-1",
    19: "dots-2",
    20: "dots-3",
    21: "dots-4",
    22: "dots-5",
    23: "dots-6",
    24: "dots-7",
    25: "dots-8",
    26: "dots-9",
}


class FanType:
    DEFAULT = 0
    SINGLE_GONG = 1  # 一个杠
    DOUBLE_GONG = 2  # 两个杠
    TRIPLE_GONG = 3  # 三个杠
    QUADRUPLE_GONG = 5
    DA_DUI_ZI = 6  # 大对子
    SEVEN_PAIRS = 7  # 七对子
    MEN_QING = 8  # 门清
    GONG_HUA = 9  # 杠上花
    GONG_PAO = 10  # 杠上炮
    HAI_DI = 11  # 海底捞月
    QING_YI_SE = 12  # 清一色
    ZI_MO = 13  # 自摸
    NEW_GONG = 14  # 用于记录刮风
    NO_19 = 15  # 断幺九
    AN_GONG = 16  # 暗杠
    ROB_GONG = 17  # 抢杠


class FanLevel:
    Zero = 0
    One = 1
    Two = 2
    Three = 3
    Four = 4
    Five = 4
