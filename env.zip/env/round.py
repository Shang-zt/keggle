from __future__ import annotations
from typing import List, Union

from mahjong.env.player import MahjongPlayer, MahjongDealer
from mahjong.env.judger import MahjongJudger as Judger
from mahjong.env.const import ActionType, WinType, FanType
from mahjong.env.env_utils import CommonUtil, find_fan
from mahjong.env.score import MahjongScore


def guafeng(players, player_id, score):
    assert score == 1 or score == 2
    if score == 2:
        fan = FanType.AN_GONG
    else:
        fan = FanType.NEW_GONG
    for iid in range(len(players)):
        if players[iid].has_win == WinType.NOT_WIN and iid != player_id:
            players[iid].score_types.append(MahjongScore.new_one(False, iid, player_id, [fan], None))
            players[player_id].score_types.append(MahjongScore.new_one(True, iid, player_id, [fan], None))


def xiayu(players, player_id, other_id):
    fan = FanType.AN_GONG
    players[other_id].score_types.append(MahjongScore.new_one(False, other_id, player_id, [fan], None))
    players[player_id].score_types.append(MahjongScore.new_one(True, other_id, player_id, [fan], None))


class MahjongRound:
    def __init__(self):
        self.current_player_id = 0
        self.is_game_over = False
        self.winner = []
        self.loser = None
        self.lis_pid_order = []
        self.last_action = None
        self.last_player = None
        self.last_hu_val = None

    def proceed_round(
        self, players: List[MahjongPlayer], dealer: MahjongDealer, action_key: str, action_val: Union[int, MahjongScore]
    ) -> bool:
        """Call other Classes's functions to keep one round running

        Args:
            players (list): object of MJPlayer
            dealer (object): object of Dealer
            action_key (str): string of legal action
            action_val (str):
        Return:
            (bool): indicates whether this round is done or not.
                    False only if the dealer has no card in deck according to the rules
        """

        def set_extra_actions(iid, action_dict):
            players[iid].valid_act = {}
            if action_dict.get("set_hu", None) is not None:
                v = action_dict["set_hu"]
                players[iid].valid_act[ActionType.ActionTypeHu] = v["card_id"]
                players[iid].valid_act[ActionType.ActionTypePassHu] = 1
                # print(v)
                players[iid].set_win_type(win_type=v["win_type"])
                if "add_gong_card" in v:
                    players[iid].rob_gong_card = v["add_gong_card"]
                return
            if action_dict.get("set_draw", None) is not None:
                players[iid].valid_act[ActionType.ActionTypeDraw] = 1
                return
            if action_dict.get("set_drawGuaFeng", None):
                players[iid].valid_act[ActionType.ActionTypeDrawGuaFeng] = 1
                return
            if action_dict.get("set_pong", None) is not None:
                v = action_dict["set_pong"]
                players[iid].valid_act[ActionType.ActionTypePong] = v
                players[iid].valid_act[ActionType.ActionTypePass] = 1
                return
            if action_dict.get("set_gong", None) is not None:
                players[iid].valid_act[ActionType.ActionTypeGong] = action_dict["set_gong"]
                players[iid].valid_act[ActionType.ActionTypePong] = action_dict["set_gong"]
                players[iid].valid_act[ActionType.ActionTypePass] = 1
                return
            assert False

        dealer_result = True
        if action_key == ActionType.ActionTypePass:
            # 选择过, 按pid_order选择下一个玩家
            # cur_index = self.lis_pid_order[0]
            # next_user = self.lis_pid_order[cur_index + 1]
            players[self.current_player_id].valid_act = dict()
            if len(self.lis_pid_order) > 1:
                self.lis_pid_order.pop(0)
                next_user = self.lis_pid_order[0][0]
                set_extra_actions(next_user, self.lis_pid_order[0][1])  # players[next_user]
                # next_user = self.lis_pid_order[cur_index + 1]
            else:
                next_user = CommonUtil.get_valid_next_player(self.current_player_id, players)
            self.current_player_id = next_user
            if (
                len(players[self.current_player_id].valid_act) == 1
                and ActionType.ActionTypeDraw in players[self.current_player_id].valid_act
            ):
                dealer_result = players[self.current_player_id].draw_card(dealer)
                self.last_action = ActionType.ActionTypeDraw
                self.last_player = self.current_player_id
                self.lis_pid_order = []
        elif action_key == ActionType.ActionTypePassHu:
            # 选择不胡,则从valid_act中去除Hu/PassHu两个选项
            players[self.current_player_id].pass_hu()
            if len(self.lis_pid_order) > 1:
                self.lis_pid_order.pop(0)
                next_user = self.lis_pid_order[0][0]
                set_extra_actions(next_user, self.lis_pid_order[0][1])  # players[next_user]
                # next_user = self.lis_pid_order[cur_index + 1]
            else:
                next_user = self.current_player_id  # CommonUtil.get_valid_next_player(self.current_player_id, players)
            self.current_player_id = next_user
            # DEBUG
            # print(self.current_player_id,players[self.current_player_id].valid_act)
            # if len(players[self.current_player_id].valid_act) == 1 and \
            #         ActionType.ActionTypeDraw in players[self.current_player_id].valid_act:
            #     dealer_result = players[self.current_player_id].draw_card(dealer)
            # print(len(self.lis_pid_order),next_user,players[self.current_player_id].valid_act)
            if len(players[self.current_player_id].valid_act) == 0:
                dealer_result = players[self.current_player_id].draw_card(dealer)
                self.lis_pid_order = []
            elif (
                len(players[self.current_player_id].valid_act) == 1
                and ActionType.ActionTypeDraw in players[self.current_player_id].valid_act
            ):
                dealer_result = players[self.current_player_id].draw_card(dealer)
                self.lis_pid_order = []

        elif action_key == ActionType.ActionTypeGong:
            # 选择杠,下一轮依然为自己
            other_id = players[self.current_player_id].gong_card(dealer, action_val)  # gong_card_id
            assert other_id != -1
            dealer_result = players[self.current_player_id].draw_card(dealer)
            self.last_action = ActionType.ActionTypeDraw
            self.last_player = self.current_player_id
            self.lis_pid_order = []
            # guafeng(players, self.current_player_id, 1)
            xiayu(players, self.current_player_id, other_id)
        elif action_key == ActionType.ActionTypeConcealedGong:
            # 选择暗杠,下一轮依然为自己
            players[self.current_player_id].concealed_gong_card(action_val)  # gong_card_id
            dealer_result = players[self.current_player_id].draw_card(dealer)
            self.last_action = ActionType.ActionTypeDraw
            self.last_player = self.current_player_id
            self.lis_pid_order = []
            guafeng(players, self.current_player_id, 2)
        elif action_key == ActionType.ActionTypeAddGong:
            # 选择加杠
            players[self.current_player_id].gong_card(dealer, action_val)
            self.lis_pid_order, total_fan = Judger.is_rob_gong_card(players, dealer, self.current_player_id)
            # print('is target',self.lis_pid_order)
            self.last_action = action_key
            self.last_player = self.current_player_id
            if len(self.lis_pid_order) > 0:
                # 新加杠的牌可被其他玩家胡
                self.last_hu_val = total_fan
                self.current_player_id = self.lis_pid_order[0][0]
                set_extra_actions(self.current_player_id, self.lis_pid_order[0][1])  # players[next_user]
            else:
                # 新加杠的牌无法被胡,直接给原先的玩家发牌
                dealer_result = players[self.current_player_id].draw_card(dealer)
                self.last_action = ActionType.ActionTypeDraw
                self.last_player = self.current_player_id
                guafeng(players, self.last_player, 1)

        elif action_key == ActionType.ActionTypePong:
            # 选择碰,下一轮依然为自己
            players[self.current_player_id].pong_card(dealer, action_val)  # pong_card_id
            self.last_action = action_key
            self.last_player = self.current_player_id
            self.lis_pid_order = []

        elif action_key == ActionType.ActionTypeDiscard:
            # 选择弃牌，需要更新pid_order, 并更新
            players[self.current_player_id].play_card_id(dealer, action_val)
            assert len(players[self.current_player_id].hand) % 3 == 1
            card_to_use = dealer.get_table_top()  # 可以被其他玩家胡/碰/杠/吃的牌
            self.lis_pid_order, total_fan = Judger.is_target_card(players, self.current_player_id, dealer, card_to_use)
            # print('is target ',self.lis_pid_order)
            # DEBUG
            # print('is target', self.lis_pid_order)
            self.last_action = action_key
            self.last_player = self.current_player_id
            if len(self.lis_pid_order) > 0:
                # 新打出的牌可被胡/碰/杠/吃
                self.last_hu_val = total_fan
                self.current_player_id = self.lis_pid_order[0][0]
                set_extra_actions(self.current_player_id, self.lis_pid_order[0][1])  # players[next_user]
            else:
                # 新打出的牌无法被胡/碰/杠/吃, 给默认的下家发一张牌,
                next_player = CommonUtil.get_valid_next_player(players[self.current_player_id].get_player_id(), players)
                self.current_player_id = next_player
                dealer_result = players[self.current_player_id].draw_card(dealer)
                # print(self.current_player_id,players[self.current_player_id].get_hand_str())
                self.last_action = ActionType.ActionTypeDraw
                self.last_player = self.current_player_id
        elif action_key == ActionType.ActionTypeDraw:
            dealer_result = players[self.current_player_id].draw_card(dealer)
            self.last_action = action_key
            self.last_player = self.current_player_id
        elif action_key == ActionType.ActionTypeDrawGuaFeng:
            dealer_result = players[self.current_player_id].draw_card(dealer)
            self.last_action = action_key
            self.last_player = self.current_player_id
            guafeng(players, self.current_player_id, 1)
        elif action_key == ActionType.ActionTypeHu:
            if players[self.current_player_id].rob_gong_card is not None:
                players[players[self.current_player_id].rob_gong_card.user_id].remove_kong(
                    players[self.current_player_id].rob_gong_card
                )
                players[self.current_player_id].is_rob_the_gong = True
                # TODO: 检查是否需要呼叫转移
            hu_card = players[self.current_player_id].hu(dealer)
            assert action_val is not None and isinstance(action_val, MahjongScore)
            action_val_id = action_val.loss_id
            action_val_fan_type_list = action_val.fan_type
            if FanType.GONG_PAO in action_val_fan_type_list:
                assert action_val_id != -1, "gong pao must after only one player discard a card"
                last_fan = players[action_val_id].score_types_record[-1]
                for item in last_fan:
                    assert item.is_pos
                action_val_fan_type_list = action_val_fan_type_list + last_fan  # 呼叫转移
            if action_val_id != -1:
                players[self.current_player_id].score_types.append(
                    MahjongScore.new_one(True, action_val_id, self.current_player_id, action_val_fan_type_list, None)
                )
                players[action_val_id].score_types.append(
                    MahjongScore.new_one(False, action_val_id, self.current_player_id, action_val_fan_type_list, None)
                )
            else:
                for iid in CommonUtil.get_valid_players(players):
                    if iid == self.current_player_id:
                        continue
                    players[self.current_player_id].score_types.append(
                        MahjongScore.new_one(True, iid, self.current_player_id, action_val_fan_type_list, None)
                    )
                    players[iid].score_types.append(
                        MahjongScore.new_one(False, iid, self.current_player_id, action_val_fan_type_list, None)
                    )
            self.winner.append(self.current_player_id)
            if len(self.winner) >= 3:
                self.is_game_over = True
            else:
                if len(self.lis_pid_order) > 0:
                    self.lis_pid_order = [self.lis_pid_order[0]] + [
                        i
                        for i in self.lis_pid_order
                        if "set_pong" not in i[1] and "set_gong" not in i[1] and i[0] != self.current_player_id
                    ]
                # print(self.lis_pid_order)
                if len(self.lis_pid_order) > 1:
                    self.lis_pid_order.pop(0)
                    next_user = self.lis_pid_order[0][0]
                    if self.lis_pid_order[0][1].get("set_draw", False):
                        next_user = CommonUtil.get_valid_next_player(self.current_player_id, players)
                        # print(next_user)
                    else:
                        set_extra_actions(next_user, self.lis_pid_order[0][1])  # players[next_user]
                    # next_user = self.lis_pid_order[cur_index + 1]
                else:
                    next_user = CommonUtil.get_valid_next_player(self.current_player_id, players)
                    self.lis_pid_order = []
                    # print('here')
                # DEBUG
                # print('next user after hu ', next_user)
                # print(players[next_user].valid_act)
                self.current_player_id = next_user

                if (
                    len(players[self.current_player_id].valid_act) == 1
                    and ActionType.ActionTypeDraw in players[self.current_player_id].valid_act
                ):
                    dealer_result = players[self.current_player_id].draw_card(dealer)
                    self.last_action = ActionType.ActionTypeDraw
                    self.last_player = self.current_player_id
                    self.lis_pid_order = []
                elif len(players[self.current_player_id].valid_act) == 0:
                    dealer_result = players[self.current_player_id].draw_card(dealer)
                    self.last_action = ActionType.ActionTypeDraw
                    self.last_player = self.current_player_id
                    self.lis_pid_order = []
                else:
                    if (
                        ActionType.ActionTypeHu in players[self.current_player_id].valid_act
                        and len(self.lis_pid_order) > 0
                    ):
                        dealer.push_table_top(hu_card, pid=self.current_player_id)
                    # self.last_player = self.current_player_id

        elif action_key == ActionType.ActionTypeDingQue:
            players[self.current_player_id].que_men = action_val
            cur_index = self.current_player_id
            next_user = CommonUtil.get_next_player(cur_index)
            self.current_player_id = next_user
        else:
            assert False

        # 查叫
        if dealer_result is False:
            self.is_game_over = True
            have_jiao = []
            not_have_jiao = []
            for player_id in range(4):
                if players[player_id].has_win == WinType.NOT_WIN:
                    ting_result = Judger.judge_ting(
                        lis_hand=[c.card_id for c in players[player_id].hand],
                        dic_hand_id2cnt=players[player_id].dic_hand_id2cnt,
                        que_men=players[player_id].que_men,
                        set_count=(len(players[player_id].pile) + len(players[player_id].hidden_pile)),
                        player=players[player_id],
                    )
                    if ting_result is not None:
                        have_jiao.append([player_id, ting_result])
                    else:
                        not_have_jiao.append(player_id)

            for ting_id, ting_score in have_jiao:
                for not_ting in not_have_jiao:
                    import copy

                    pos_ting_score = copy.deepcopy(ting_score)
                    pos_ting_score.is_pos = True
                    neg_ting_score = copy.deepcopy(ting_score)
                    neg_ting_score.is_pos = False
                    players[ting_id].score_types.append(pos_ting_score)
                    players[not_ting].score_types.append(neg_ting_score)

        ###############################################################
        # calculate score
        for player in players:
            player.update_score()

        ###############################################################
        return True

    def get_player_state(self, players, dealer, player_id):
        state = {}
        valid_act = []
        gong_card_ids = None
        concealed_gong_card_ids = None
        add_gong_card_ids = None
        pong_card_ids = None

        if self.is_game_over is True or player_id != self.current_player_id or player_id in self.winner:
            pass
            # TODO: 这里是否是assert 0
        elif players[player_id].que_men is None:
            valid_act = [ActionType.ActionTypeDingQue]
        else:
            if len(players[player_id].hand) % 3 == 2:
                # player_id can choose hu/gong/discard
                if len(players[player_id].valid_act) == 0:
                    win_type = None
                    is_add_gong = False
                    is_concealed_gong = False
                    if players[player_id].discard_only is False:
                        # check current player is win or not
                        win_type = Judger.judge_hu(
                            lis_hand=[c.card_id for c in players[player_id].hand],
                            dic_hand_id2cnt=players[player_id].dic_hand_id2cnt,
                            set_count=(len(players[player_id].pile) + len(players[player_id].hidden_pile)),
                            win_tile_id=None,
                            que_men=players[player_id].que_men,
                        )
                        # TODO: 检查原来这里的两个判断是干什么的
                        # if len(dealer.lis_deck[player_id]) > 0:
                        #     if len(dealer.lis_deck[(player_id + 1) % 4]) > 0:
                        is_add_gong, add_gong_card_ids = Judger.judge_add_gong(players[player_id])
                        is_concealed_gong, concealed_gong_card_ids = Judger.judge_concealed_gong(players[player_id])
                    dic_valid_act = dict()
                    if win_type is not None:

                        total_fan = Judger.calculate_fan_all_simple(
                            players[player_id], dealer, win_card=None, is_rob_the_gong=False, win_type=win_type
                        )
                        self.last_hu_val = total_fan
                        assert total_fan is not None
                        if total_fan is not None:
                            dic_valid_act[ActionType.ActionTypeHu] = players[player_id].hand[-1].get_card_id()
                            dic_valid_act[ActionType.ActionTypePassHu] = 1
                            players[player_id].set_win_type(win_type=win_type)
                    if is_concealed_gong:
                        dic_valid_act[ActionType.ActionTypeConcealedGong] = concealed_gong_card_ids
                    if is_add_gong:
                        dic_valid_act[ActionType.ActionTypeAddGong] = add_gong_card_ids
                    dic_valid_act[ActionType.ActionTypeDiscard] = 1
                    players[player_id].valid_act = dic_valid_act
                    valid_act = valid_act + list(dic_valid_act.keys())
                else:
                    valid_act = list(players[player_id].valid_act.keys())

                    if ActionType.ActionTypeGong in valid_act:
                        gong_card_ids = players[player_id].valid_act[ActionType.ActionTypeGong]
                    if ActionType.ActionTypeConcealedGong in valid_act:
                        concealed_gong_card_ids = players[player_id].valid_act[ActionType.ActionTypeConcealedGong]
                    if ActionType.ActionTypeAddGong in valid_act:
                        add_gong_card_ids = players[player_id].valid_act[ActionType.ActionTypeAddGong]
                    if ActionType.ActionTypePong in valid_act:
                        raise AssertionError
            else:
                valid_act = valid_act + list(players[player_id].valid_act.keys())
                if ActionType.ActionTypePong in players[player_id].valid_act:
                    pong_card_ids = players[player_id].valid_act[ActionType.ActionTypePong]
                if ActionType.ActionTypeGong in players[player_id].valid_act:
                    gong_card_ids = players[player_id].valid_act[ActionType.ActionTypeGong]

        state["valid_act"] = valid_act

        if ActionType.ActionTypeDiscard in valid_act:
            state["play_cards"] = list(players[player_id].dic_hand_id2cnt.keys())
            not_que = True
            que_list = []
            for cid in state["play_cards"]:
                if cid // 9 == players[player_id].que_men:
                    que_list.append(cid)
                    not_que = False
            if not not_que:
                state["play_cards"] = que_list
        if ActionType.ActionTypePong in valid_act:
            state["pong_cards"] = pong_card_ids  # eg: [1,2,3]
        if ActionType.ActionTypeGong in valid_act:
            state["gong_cards"] = gong_card_ids  # eg: [1,2,3]
        if ActionType.ActionTypeConcealedGong in valid_act:
            state["concealed_gong_cards"] = concealed_gong_card_ids  # eg: [1,2,3]
        if ActionType.ActionTypeAddGong in valid_act:
            state["add_gong_cards"] = add_gong_card_ids

        state["table"] = dealer.table  # eg: [MahjongCard, MahjongCard]
        state["lis_deck"] = dealer.lis_deck
        state["player_id"] = player_id  # eg: 0
        state["current_player"] = self.current_player_id
        state["players_hand"] = {p.player_id: p.hand for p in players}
        state["players_pile"] = {
            p.player_id: p.pile for p in players
        }  # eg: {1: [[MahjongCard, MahjongCard]. [MahjongCard, MahjongCard]]}
        state["players_hidden_pile"] = {p.player_id: p.hidden_pile for p in players}
        state["history_cards"] = {p.player_id: p.history_card for p in players}  # eg: {1: [MahjongCard, MahjongCard]}
        state["history_action"] = {
            p.player_id: p.history_action for p in players
        }  # eg: {1: [MahjongAction, MahjongAction]}
        state["is_over"] = self.is_game_over
        state["is_rob_the_gong"] = players[player_id].is_rob_the_gong
        state["que_men"] = [players[i].que_men for i in range(4)]
        state["score"] = [p.score for p in players]
        state["has_win"] = [p.has_win for p in players]

        state["Fan_duan19"] = [find_fan(p, FanType.NO_19) for p in players]
        state["Fan_menqing"] = [find_fan(p, FanType.MEN_QING) for p in players]
        state["Fan_self_draw"] = [find_fan(p, FanType.ZI_MO) for p in players]
        state["Fan_qingyise"] = [find_fan(p, FanType.QING_YI_SE) for p in players]
        state["Fan_daduizi"] = [find_fan(p, FanType.DA_DUI_ZI) for p in players]

        state["last_action"] = self.last_action
        state["last_player"] = self.last_player
        return state
