from mahjong.env.dealer import MahjongDealer as Dealer
from mahjong.env.player import MahjongPlayer as Player
from mahjong.env.round import MahjongRound as Round
from mahjong.env.env_utils import CommonUtil
from mahjong.env.const import ActionLabelRange, ActionType


class MahjongGame:
    def __init__(self):
        """Initialize the class MahjongGame"""
        self.player_num = 4
        self.players = []
        self.action_space = ActionLabelRange.ACTION_NULL
        self.card_num = 27
        self.init_card_num = 13
        self.base_score = 8

        self.dealer = None
        self.round = None
        self.winner = None
        self.loser = None
        self.state = None
        self.payoffs = None

    def init_game(self, test_config=None):
        self.players = [Player(i) for i in range(self.player_num)]
        self.dealer = Dealer(test_config)
        self.round = Round()
        self.winner = None
        self.payoffs = None
        self.loser = None
        for player in self.players:
            deal_result = self.dealer.deal_cards(player, self.init_card_num)
            if deal_result is False:
                raise RuntimeError("Fail to deal cards.")

        self.dealer.deal_cards(self.players[self.round.current_player_id], 1)
        self.state = self.round.get_player_state(self.players, self.dealer, self.round.current_player_id)
        return self.state

    def step(self, action: int):
        action_key, action_val = CommonUtil.trans_actions_from_label2keyval(action)
        if action_key == ActionType.ActionTypeHu:
            action_val = self.round.last_hu_val

        self.round.proceed_round(self.players, self.dealer, action_key, action_val)
        self.state = self.round.get_player_state(self.players, self.dealer, self.round.current_player_id)
        return self.state

    def get_done(self):
        return self.round.is_game_over

    def get_payoffs(self):
        self.winner = self.round.winner
        self.loser = self.round.loser

        old_payoffs = [0] * self.player_num if self.payoffs is None else self.payoffs
        self.payoffs = [player.score for player in self.players]
        payoffs = [a - b for a, b in zip(self.payoffs, old_payoffs)]
        return payoffs

    def get_player_state(self, player_id):
        self.state = self.round.get_player_state(self.players, self.dealer, player_id)
        return self.state
