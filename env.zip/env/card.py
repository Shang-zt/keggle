from mahjong.env.const import ActionType, CardId2StrDict


class MahjongCard:
    def __init__(self, card_id: int, user_id: int = -1):
        self.card_id = card_id
        self.user_id = user_id
        self.type = CardId2StrDict[card_id].split("-")[0]
        self.trait = CardId2StrDict[card_id].split("-")[1]
        self.gonging = False  # 用于记录该牌是不是杠后的第一张
        self.actioned_type = ActionType.ActionTypeNull  # 若该牌被别的玩家吃碰杠,分别标记为ActionTypeChow/ActionTypePong/ActionTypeGong

    def set_user_id(self, user_id: int):
        self.user_id = user_id

    def get_user_id(self) -> int:
        return self.user_id

    def get_card_type_id(self) -> int:
        return self.card_id // 9

    def get_card_id(self) -> int:
        return self.card_id

    def get_card_str(self) -> str:
        return self.type + "-" + self.trait
