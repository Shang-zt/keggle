import numpy as np


def _np_onehot(x, depth):
    x_shape = x.shape
    x[x < 0] = depth
    x[x > depth] = depth
    x = np.eye(depth + 1)[x.reshape(-1)]
    x = x.reshape(*x_shape, depth + 1)
    x = x[..., :depth]
    return x


def _que_men_emb(x):
    x = x[0]
    ret = []
    for que in x:
        if que == -1:
            ret.append(np.zeros(3))
        else:
            ret.append(np.zeros(3))
            ret[-1][int(que)] = 1
    ret = np.stack(ret)
    return np.reshape(ret, [1, -1])


def _onehot_emb(x, depth):
    x = np.array(x, dtype=int)
    x = _np_onehot(x, depth)
    x = np.reshape(x, [x.shape[0], -1])
    return x


def _c_kong_emb(x, depth):
    x = x[:, :, :depth]
    x = np.clip(x, 0, 1)
    x = np.reshape(x, [x.shape[0], -1])
    return x


def _hand_emb(x, depth):
    x = _np_onehot(x, depth)
    x = np.sum(x, axis=-2)
    x = np.concatenate([x, x - 1, x - 2, x - 3], axis=1)
    x = np.clip(x, 0, 1)
    return [x]


def _chow_emb(x, depth):
    x = np.reshape(x, [x.shape[0], -1])
    x_none = np.less(x, 0)
    x_none = np.array(x_none, dtype=int)

    x_mod = x // 3 + 2 * (x // 21)
    x0 = x_mod - 2 * x_none
    x0 = np.expand_dims(x0, axis=-1)
    x0 = np.concatenate([x0, x0 + 1, x0 + 2], axis=-1)
    x0 = _np_onehot(x0, depth=depth)
    x0 = np.sum(x0, axis=-2)

    x1 = x_mod + x % 3 - 4 * x_none
    x1 = _np_onehot(x1, depth=depth)

    return [x0, x1]


def _pong_kong_emb(x, depth, seq=True):
    if seq:
        x = np.reshape(x, [x.shape[0], -1])
        x = _np_onehot(x, depth=depth)
    else:
        x = _np_onehot(x, depth=depth)
        x = np.sum(x, axis=-2)
    return [x]


def _pad_cards_27(cards):
    cards = np.concatenate(cards, axis=1)
    cards = np.expand_dims(cards, axis=2)
    # cards = np.split(cards, [9, 9 + 9, 9 + 9 + 9], axis=-1)
    # cards[-1] = np.pad(cards[-1], ((0, 0), (0, 0), (0, 0), (1, 1)), 'constant')
    # cards = np.concatenate(cards, axis=2)
    # cards = np.transpose(cards, [0, 2, 3, 1])
    # print(cards.shape)
    cards = np.reshape(cards, [cards.shape[0], -1])
    return cards


def _pad_cards(cards):
    cards = np.concatenate(cards, axis=1)
    cards = np.expand_dims(cards, axis=2)
    cards = np.split(cards, [9, 9 + 9, 9 + 9 + 9], axis=-1)
    cards[-1] = np.pad(cards[-1], ((0, 0), (0, 0), (0, 0), (1, 1)), "constant")
    cards = np.concatenate(cards, axis=2)
    # cards = np.transpose(cards, [0, 2, 3, 1])
    cards = np.reshape(cards, [cards.shape[0], -1])
    # print(cards.shape)
    return cards


def _drop_emb(x, depth, seq=True):
    if seq:
        x = np.reshape(x, [x.shape[0], -1])
        x = _np_onehot(x, depth=depth)
    else:
        x = _np_onehot(x, depth=depth)
        x = np.sum(x, axis=-2)
        x = np.expand_dims(x, axis=-2)
        x = np.concatenate([x, x - 1, x - 2, x - 3], axis=-2)
        x = x.reshape([-1, 16, depth])
        x = np.clip(x, 0, 1)
    return [x]


def _2d_quemen_emb(que_men, depth):
    x = np.zeros([1, 4, depth])
    for i, que in enumerate(que_men[0]):
        if que == -1:
            continue
        else:
            x[0][i][int(que * 9) : int(que * 9) + 9] = 1
    return [x]


def _cal_remain(x):
    hand = np.sum(x[0], axis=1)
    # chow = np.sum(x[1], axis=1) - np.sum(x[2], axis=1)
    pong = 2 * np.sum(x[1], axis=1)
    kong = 4 * np.sum(x[2], axis=1)
    drop = np.sum(x[3], axis=1)
    x = 4 * np.ones_like(hand) - hand - pong - kong - drop
    x = np.stack([x, x - 1, x - 2, x - 3], axis=1)
    x = np.clip(x, 0, 1)

    return [x]


def _men_quan_emb(x, depth):
    x = _np_onehot(x, depth=depth)
    # 东南西北 -> 东西北南
    x = np.concatenate([x[..., 0:1], x[..., 2:3], x[..., 3:4], x[..., 1:2]], axis=-1)
    x = np.pad(x, ((0, 0), (0, 0), (30, 0)), "constant")
    return [x]


def feature_function(state, output_global_info=False):
    raise DeprecationWarning("Use feature_function_27 instead")
    feature = np.array(state["obs"], dtype=float)
    obs_dim = 496
    if output_global_info:
        others_hands_dim = 34 * 3
        deck_list_dim = 21 * 4
    else:
        others_hands_dim = 0
        deck_list_dim = 0
    feature = np.reshape(feature, [-1, obs_dim + others_hands_dim + deck_list_dim])

    cards, callings, actions, user_id, others_hands, deck_list = np.split(
        feature, [443, 443 + 48, 491 + 4, 495 + 1, 496 + others_hands_dim], axis=-1
    )
    # print('cards, callings, actions, user_id, others_hands, deck_list',cards, callings, actions, user_id, others_hands, deck_list)
    cards = np.reshape(cards[..., :-1], [-1, 13, 34])
    cards = np.array(cards[..., :24], dtype=int)
    # print('cards ' ,cards.shape,cards)
    # assert 0

    others_hands = np.reshape(others_hands, [-1, 3, 34])
    others_hands = np.array(others_hands[..., :24], dtype=int)

    deck_list = np.reshape(deck_list, [-1, 4, 21])
    deck_list = np.array(deck_list, dtype=int)

    callings = np.reshape(callings, [-1, 4, 3, 4])
    callings = np.transpose(callings, [0, 2, 1, 3])
    callings = np.reshape(callings, [-1, 12, 4])
    callings = np.array(callings, dtype=int)

    user_id = np.reshape(user_id, [-1, 1])
    user_id = np.array(user_id, dtype=int)

    hands = cards[:, 0:1, :]
    drops = np.stack([cards[:, 3, :], cards[:, 6, :], cards[:, 9, :], cards[:, 12, :]], axis=1)
    # self c_kong is in card_concat, not global_card_concat, so 4 + 4 + 1 not 4 + 4
    callings_pong, callings_kong, callings_c_kong = np.split(callings, [4, 4 + 5], axis=1)

    card_concat = []
    card_concat += _hand_emb(hands, 34)  # 1 * 1 * 4 * 34

    # card_concat += _chow_emb(callings_chow, 34)  # 2 * 1 * 16 * 34
    card_concat += _pong_kong_emb(callings_pong, 34, seq=True)  # 1 * 1 * 16 * 34
    card_concat += _pong_kong_emb(callings_kong, 34, seq=True)  # 1 * 1 * 16 * 34
    card_concat += _drop_emb(drops, 34, seq=False)  # 1 * 1 * 16 * 34
    card_concat += _drop_emb(drops, 34, seq=True)  # 1 * 1 * 96 * 34
    card_concat += _cal_remain(card_concat)  # 1 * 1 * 4 * 34
    card_concat += _men_quan_emb(user_id, 4)  # 1 * 1 * 4 * 34

    # TODO: delete permutation in env and model
    card_concat = _pad_cards(card_concat)

    other_concat = [_onehot_emb(user_id, 4), _c_kong_emb(callings_c_kong, 3)]
    other_concat = np.concatenate(other_concat, axis=1)

    all_concat_list = [other_concat, card_concat]

    if output_global_info:
        global_card_concat = []
        global_card_concat += _hand_emb(others_hands, 34)
        global_card_concat += _drop_emb(deck_list, 34, seq=False)
        global_card_concat += _drop_emb(deck_list, 34, seq=True)
        global_card_concat = _pad_cards(global_card_concat)
        all_concat_list.append(global_card_concat)

    all_concat = np.concatenate(all_concat_list, axis=1)
    all_concat = np.array(all_concat, dtype=np.float32)

    return all_concat


def feature_function_27(state, output_global_info=False):
    feature = np.array(state["obs"], dtype=float)
    # print(feature)
    # assert 0
    obs_dim = 496 + 4 + 4
    if output_global_info:
        others_hands_dim = 34 * 3
        deck_list_dim = 21 * 4
    else:
        others_hands_dim = 0
        deck_list_dim = 0
    feature = np.reshape(feature, [-1, obs_dim + others_hands_dim + deck_list_dim])

    cards, callings, actions, user_id, que_men, has_win, others_hands, deck_list = np.split(
        feature,
        [
            443,
            443 + 48,
            491 + 4,
            495 + 1,
            496 + 4,
            500 + 4,
            504 + others_hands_dim,
        ],
        axis=-1,
    )
    cards = np.reshape(cards[..., :-1], [-1, 13, 34])
    cards = np.array(cards[..., :24], dtype=int)

    others_hands = np.reshape(others_hands, [-1, 3, 34])
    others_hands = np.array(others_hands[..., :24], dtype=int)

    deck_list = np.reshape(deck_list, [-1, 4, 21])
    deck_list = np.array(deck_list, dtype=int)

    callings = np.reshape(callings, [-1, 4, 3, 4])
    callings = np.transpose(callings, [0, 2, 1, 3])
    callings = np.reshape(callings, [-1, 12, 4])
    callings = np.array(callings, dtype=int)

    user_id = np.reshape(user_id, [-1, 1])
    user_id = np.array(user_id, dtype=int)

    hands = cards[:, 0:1, :]
    drops = np.stack([cards[:, 3, :], cards[:, 6, :], cards[:, 9, :], cards[:, 12, :]], axis=1)
    # self c_kong is in card_concat, not global_card_concat, so 4 + 4 + 1 not 4 + 4
    callings_pong, callings_kong, callings_c_kong = np.split(callings, [4, 4 + 4 + 1], axis=1)

    card_concat = []
    card_concat += _hand_emb(hands, 27)  # 1 * 1 * 4 * 27
    card_concat += _pong_kong_emb(callings_pong, 27, seq=True)  # 1 * 1 * 16 * 34
    card_concat += _pong_kong_emb(callings_kong, 27, seq=True)  # 1 * 1 * 16 * 34
    card_concat += _drop_emb(drops, 27, seq=False)  # 1 * 1 * 16 * 34
    card_concat += _drop_emb(drops, 27, seq=True)  # 1 * 1 * 96 * 34
    card_concat += _cal_remain(card_concat)  # 1 * 1 * 4 * 34
    card_concat += _2d_quemen_emb(que_men, 27)  # 1 * 1 * 4 * 27

    # TODO: delete permutation in env and model
    card_concat = _pad_cards_27(card_concat)
    other_concat = [
        _onehot_emb(user_id, 4),
        _c_kong_emb(callings_c_kong, 3),
        _que_men_emb(que_men),
        np.clip(has_win, 0, 1),
    ]
    other_concat = np.concatenate(other_concat, axis=1)
    all_concat_list = [other_concat, card_concat]

    if output_global_info:
        global_card_concat = []
        global_card_concat += _hand_emb(others_hands, 27)
        global_card_concat += _drop_emb(deck_list, 27, seq=False)
        global_card_concat += _drop_emb(deck_list, 27, seq=True)
        global_card_concat = _pad_cards_27(global_card_concat)
        all_concat_list.append(global_card_concat)

    all_concat = np.concatenate(all_concat_list, axis=1)
    all_concat = np.array(all_concat, dtype=np.float32)
    return all_concat


def get_feature_shapes():
    # flat_other_obs_shape = 13
    flat_other_obs_shape = 29
    # card_obs_shape = [157, 4, 9]
    card_obs_shape = [160, 3, 9]
    # global_card_obs_shape = [112, 4, 9]
    global_card_obs_shape = [112, 3, 9]
    flat_card_obs_shape = np.prod(card_obs_shape)
    flat_global_card_obs_shape = np.prod(global_card_obs_shape)
    flat_hidden_states_shape = flat_other_obs_shape + 64 * np.prod(card_obs_shape[1:])
    flat_global_card_hidden_states_shape = 64 * np.prod(global_card_obs_shape[1:])
    return (
        flat_other_obs_shape,
        card_obs_shape,
        global_card_obs_shape,
        flat_card_obs_shape,
        flat_global_card_obs_shape,
        flat_hidden_states_shape,
        flat_global_card_hidden_states_shape,
    )
