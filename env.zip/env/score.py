from mahjong.env.const import FanLevel, FanType


class MahjongScore:
    def __init__(self):
        self.is_pos = None
        self.loss_id = -1
        self.win_id = -1
        self.fan_type = []
        self.cause_card = None  # 记录哪一张牌搞得

    @staticmethod
    def new_one(is_pos, loss_id, win_id, fan_type, cause_card):
        tmp = MahjongScore()
        tmp.is_pos = is_pos
        tmp.loss_id = loss_id
        tmp.win_id = win_id
        tmp.fan_type = fan_type
        tmp.cause_card = cause_card
        return tmp

    def get_score(self):
        base_fen = 0
        assert len(self.fan_type) > 0, f"there must be one type before call this function {len(self.fan_type)}"
        assert (FanType.SINGLE_GONG in self.fan_type) + (FanType.DOUBLE_GONG in self.fan_type) + (
            FanType.TRIPLE_GONG in self.fan_type
        ) + (FanType.QUADRUPLE_GONG in self.fan_type) <= 1, "error，the number of gong"
        if FanType.NEW_GONG in self.fan_type or FanType.AN_GONG in self.fan_type:
            assert len(self.fan_type) == 1, "new gong error"
        if FanType.SEVEN_PAIRS in self.fan_type:
            assert FanType.MEN_QING in self.fan_type, "SEVENPAIRS and MENQING"
        for fan in self.fan_type:
            if fan == FanType.SINGLE_GONG:
                base_fen += 1
            elif fan == FanType.DOUBLE_GONG:
                base_fen += 2
            elif fan == FanType.TRIPLE_GONG:
                base_fen += 3
            elif fan == FanType.QUADRUPLE_GONG:
                base_fen += 4
            elif fan == FanType.DA_DUI_ZI:
                base_fen += 1
            elif fan == FanType.SEVEN_PAIRS:
                base_fen += 1  # 因为是七对子一定是门清
            elif fan == FanType.MEN_QING:
                base_fen += 1
            elif fan == FanType.GONG_HUA:
                base_fen += 1
            elif fan == FanType.GONG_PAO:
                base_fen += 1
            elif fan == FanType.HAI_DI:
                base_fen += 1
            elif fan == FanType.QING_YI_SE:
                base_fen += 2
            elif fan == FanType.ZI_MO:
                base_fen += 1
            elif fan == FanType.NEW_GONG:
                base_fen = 0
            elif fan == FanType.AN_GONG:
                base_fen = 1
            elif fan == FanType.NO_19:
                base_fen += 1
            elif fan == FanType.ROB_GONG:
                base_fen += 1
            elif fan == FanType.DEFAULT:
                continue
            else:
                assert False, f"unknow_fan {fan}"
        base_fen = min(4, base_fen)
        fl = [FanLevel.Zero, FanLevel.One, FanLevel.Two, FanLevel.Three, FanLevel.Four]
        return fl[base_fen]
