from __future__ import annotations

import copy
from typing import TYPE_CHECKING
import random

from mahjong.env.card import MahjongCard as Card
from mahjong.env.const import MAX_HAND_CARD_NUM, CardId2StrDict

if TYPE_CHECKING:
    from mahjong.env.player import MahjongPlayer


class MahjongDealer:
    def __init__(self, test_config=None):
        all_deck = []
        for cid in CardId2StrDict:
            for _ in range(4):
                card = Card(card_id=cid)
                all_deck.append(card)

        random.shuffle(all_deck)

        self.debug_all_deck = copy.deepcopy([i.card_id for i in all_deck])
        if test_config is not None:
            all_deck = [Card(card_id=i) for i in test_config["cards"]]
        card_num = int(len(all_deck) / 4)
        self.lis_deck = list()
        for pid in range(4):
            self.lis_deck.append(all_deck[pid * card_num : (pid + 1) * card_num])

        self.all_deck = all_deck

        self.table = []
        self.lis_table = [[], [], [], []]
        self.is_top_avail = False  # 弃牌堆顶能否被吃/杠/碰

    def get_table(self):
        return self.table

    def get_is_top_avail(self):
        return self.is_top_avail

    def set_is_top_avail(self, is_top_avail):
        self.is_top_avail = is_top_avail

    def deal_cards(self, player: MahjongPlayer, num: int):
        pid = player.get_player_id()
        if len(self.all_deck) < num:
            return False
        for _ in range(num):
            assert len(player.hand) < MAX_HAND_CARD_NUM, f"pid: {pid}, hand: {[i.get_card_str() for i in player.hand]}"
            latest_card = self.all_deck.pop(-1)
            latest_card.set_user_id(pid)
            player.hand.append(latest_card)
            player.inc_hand_card_cnt(latest_card.card_id)
            if len(self.all_deck) == 0:
                player.last_card = True
        # 发牌给玩家后,弃牌堆顶无法被胡/碰/杠/吃
        self.is_top_avail = False
        return True

    def push_table_top(self, card, pid):
        """
        card 玩家丢弃至弃牌堆顶的牌
        """
        self.table.append(card)
        # self.lis_table[pid].append(card)
        self.is_top_avail = True
        return

    def pop_table_top(self):
        """
        从弃牌堆顶弹出一张牌,给玩家胡/碰/杠/吃
        """
        if self.is_top_avail:
            assert len(self.table) > 0
            self.is_top_avail = False
            # pid = self.table[-1].user_id
            # self.lis_table[pid].pop(-1)
            return self.table.pop(-1)
        return None

    def get_table_top(self):
        if self.is_top_avail:
            assert len(self.table) > 0
            return self.table[-1]
        return None

    def get_left_cards_num(self):
        return len(self.all_deck)

    def is_empty(self):
        return len(self.all_deck) == 0
