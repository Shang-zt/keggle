from __future__ import annotations
from typing import List

from mahjong.env.const import ActionType, WinType, FanLevel
from mahjong.env.action import MahjongAction as Action
from mahjong.env.dealer import MahjongDealer


class MahjongPlayer(object):
    def __init__(self, player_id, quan_id=0):
        """Initialize a player.

        Args:
            player_id (int): The id of the player
            quan_id  (int): The quan id of player0
        """
        self.player_id = player_id
        self.quan_id = quan_id
        self.hand = []  # 手牌
        self.pile = []  # 碰/杠/吃产生的牌组
        self.hidden_pile = []  # 暗杠产生的牌组
        self.history_card = []
        self.history_action = []
        self.dic_hand_id2cnt = dict()  # 手牌中,key为card_id,cnt为card的个数
        self.pass_hu_cnt = 0  # 过胡次数
        self.valid_act = dict()
        self.add_gong_card = None  # 加杠的牌
        self.rob_gong_card = None  # 抢杠的牌
        self.is_rob_the_gong = False  # 是否为抢杠胡
        self.is_gonging = False  # 是否处于杠牌状态(加杠、明杠、暗杠之后置为True,弃牌后置为False)
        self.out_with_replacement_tile = False  # 是否为杠上开花
        self.is_first_action = True  # 是否执行了弃牌/碰/杠操作
        self.is_sky_ready_hand = False  # 是否为天听(在执行弃牌、碰、杠前,先听牌)
        self.discard_only = False
        self.win_type = WinType.NOT_WIN  # 用于原本的模拟器
        self.last_card = False
        self.has_win = WinType.NOT_WIN  # 用于血战到底
        self.fan_level = FanLevel.Zero  # 用于血战到底记录
        self.que_men = None  # 用于缺门
        self.score = 0  # 记录分数
        self.score_types: List = []  # 用于每一轮的更新，一轮以后就删掉
        self.score_types_record = []

    def update_score(self):
        for st in self.score_types:
            assert st.is_pos is not None
            self.score += (2 ** st.get_score()) if st.is_pos else -1 * (2 ** st.get_score())
        self.score_types_record.append(self.score_types)
        self.score_types = []
        # if self.has_win is True:
        #     self.update_score = None
        # if you have won, you shouldn't update your score. you can only update once when you hu.

    def get_player_id(self):
        return self.player_id

    def get_hand_card_by_id(self, card_id):
        for card in self.hand:
            if card.card_id == card_id:
                assert card.get_user_id() == self.player_id
                return card
        return None

    def get_hand_str(self):
        return [c.get_card_str() for c in self.hand]

    def get_pile_str(self):
        return [[c.get_card_str() for c in s] for s in self.pile]

    def get_concealed_pile_str(self):
        return [[c.get_card_str() for c in s] for s in self.hidden_pile]

    def play_card_id(self, dealer: MahjongDealer, card_id):
        """Play one card
        Args:
            dealer (object): Dealer
            card_id (int): The id of hand_card to be play.
        """
        self.is_first_action = False
        card = self.get_hand_card_by_id(card_id)
        card.is_gonging = self.is_gonging
        assert card is not None

        action = Action()
        action.action_type = ActionType.ActionTypeDiscard
        action.player_id = self.player_id
        action.target_card = card
        self.history_action.append(action)
        self.hand.pop(self.hand.index(card))
        self.dec_hand_card_cnt(card.card_id)
        self.history_card.append(card)
        dealer.push_table_top(card, pid=self.player_id)

        self.is_gonging = False
        self.valid_act = dict()
        self.discard_only = False
        self.win_type = WinType.NOT_WIN
        return

    def gong_card(self, dealer: MahjongDealer, gong_card_id):
        """Perform Gong
        Args:
            dealer (object): Dealer
            gong_card_id (int): The card to be Gong.
        """
        self.is_first_action = False
        action = Action()
        action.action_type = ActionType.ActionTypeGong
        action.player_id = self.player_id

        cards = list()
        for card in self.hand:
            if card.get_card_id() == gong_card_id:
                cards.append(card)
                action.assist_card.append(card)
        is_gong_after_pong = False
        other_id = -1
        if len(cards) == 1:
            # 加杠
            action.action_type = ActionType.ActionTypeAddGong
            action.target_card = action.assist_card.pop(-1)
            for cur_pile in self.pile:
                cnt = 0
                for pile_card in cur_pile:
                    if pile_card.card_id == gong_card_id:
                        cnt += 1
                if cnt == 3:
                    cur_pile.append(action.target_card)
                    is_gong_after_pong = True
                    break

            self.add_gong_card = cards[0]  # 加杠的牌
            assert is_gong_after_pong is True

        elif len(cards) == 3:
            # 杠别人打出的牌
            last_card = dealer.pop_table_top()
            action.from_player_id = last_card.user_id
            other_id = action.from_player_id
            last_card.actioned_type = ActionType.ActionTypeGong
            assert last_card is not None and last_card.get_card_id() == gong_card_id
            action.target_card = last_card
            cards.append(last_card)
        else:
            assert False
        for card in cards:
            if card in self.hand:
                self.hand.pop(self.hand.index(card))
                self.dec_hand_card_cnt(card.card_id)
        if is_gong_after_pong is False:
            # 若非加杠,需要通过append更新pile
            self.pile.append(cards)
        self.history_action.append(action)
        self.valid_act = dict()
        self.is_gonging = True
        self.win_type = WinType.NOT_WIN
        return other_id

    def concealed_gong_card(self, gong_card_id: int):
        self.is_first_action = False
        action = Action()
        action.action_type = ActionType.ActionTypeConcealedGong
        action.player_id = self.player_id

        cards = list()
        for card in self.hand:
            if card.get_card_id() == gong_card_id:
                cards.append(card)
                action.assist_card.append(card)
        if len(cards) == 4:
            action.target_card = action.assist_card.pop(-1)
        else:
            assert False
        self.hidden_pile.append(cards)
        for card in cards:
            if card in self.hand:
                self.hand.pop(self.hand.index(card))
                self.dec_hand_card_cnt(card.card_id)
        self.history_action.append(action)
        self.valid_act = dict()
        self.is_gonging = True
        self.win_type = WinType.NOT_WIN
        return

    def pong_card(self, dealer: MahjongDealer, pong_card_id):
        """Perform Pong
        Args:
            dealer (object): Dealer
            pong_card_id (int): The cards to be Pong.
        """
        self.is_first_action = False
        last_card = dealer.pop_table_top()
        last_card.actioned_type = ActionType.ActionTypePong
        assert last_card is not None and last_card.get_card_id() == pong_card_id

        action = Action()
        action.action_type = ActionType.ActionTypePong

        action.player_id = 0
        action.target_card = last_card
        cards = list()
        for card in self.hand:
            if card.get_card_id() == pong_card_id:
                cards.append(card)
                action.assist_card.append(card)
            if len(cards) == 2:
                break
        for card in cards:
            if card in self.hand:
                self.hand.pop(self.hand.index(card))
                self.dec_hand_card_cnt(card.card_id)
        cards.append(last_card)
        assert len(cards) == 3

        self.pile.append(cards)
        self.history_action.append(action)
        self.valid_act = dict()
        self.discard_only = True
        self.win_type = WinType.NOT_WIN
        return

    def hu(self, dealer):
        assert self.win_type != WinType.NOT_WIN
        self.has_win = self.win_type
        if len(self.hand) % 3 == 2:
            if self.is_gonging is True:
                self.out_with_replacement_tile = True
            return
        # print(self.rob_gong_card)
        card = dealer.pop_table_top() if self.rob_gong_card is None else self.rob_gong_card
        assert card is not None
        self.hand.append(card)
        self.inc_hand_card_cnt(card.card_id)
        return card

    def pass_hu(self):
        """
        过胡
        :return:
        """
        self.pass_hu_cnt += 1
        assert ActionType.ActionTypeHu in self.valid_act
        assert ActionType.ActionTypePassHu in self.valid_act
        self.valid_act.pop(ActionType.ActionTypeHu)
        self.valid_act.pop(ActionType.ActionTypePassHu)
        self.rob_gong_card = None  # 重置抢杠和
        self.win_type = WinType.NOT_WIN
        return

    def draw_card(self, dealer: MahjongDealer):
        """Perform Draw
        Args:
            dealer (object): Dealer
        """
        dealer_ret = dealer.deal_cards(self, 1)  # give him one new card
        self.valid_act = dict()
        self.win_type = WinType.NOT_WIN
        return dealer_ret

    def remove_kong(self, card):
        assert card is not None
        for pile_set in self.pile:
            if card in pile_set:
                pile_set.pop(pile_set.index(card))
                break
        return

    def set_win_type(self, win_type):
        assert win_type is not None and win_type != WinType.NOT_WIN
        self.win_type = win_type
        return

    def inc_hand_card_cnt(self, card_id):
        self.dic_hand_id2cnt[card_id] = self.dic_hand_id2cnt.get(card_id, 0) + 1

    def dec_hand_card_cnt(self, card_id):
        assert self.dic_hand_id2cnt[card_id] > 0
        if self.dic_hand_id2cnt[card_id] == 1:
            del self.dic_hand_id2cnt[card_id]
        else:
            self.dic_hand_id2cnt[card_id] -= 1
